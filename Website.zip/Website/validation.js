// Register Form Validation
function validateRegisterForm() {
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    // Validate Name
    if (name.trim() === "") {
        alert("Name cannot be empty.");
        return false;
    }

    // Validate Email with Regex
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert("Invalid email format.");
        return false;
    }

    // Validate Phone Number with Regex (Assuming numeric format)
    const phoneRegex = /^\d{10}$/; // Example: 10 digit phone number
    if (!phoneRegex.test(phone)) {
        alert("Phone number must be 10 digits.");
        return false;
    }

    // Validate Password Length and Complexity
    const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    if (!passwordRegex.test(password)) {
        alert("Password must be at least 8 characters long, contain one uppercase letter, one number, and one special character.");
        return false;
    }

    // Validate Confirm Password
    if (password !== confirmPassword) {
        alert("Passwords do not match.");
        return false;
    }

    // If all validations pass, allow the form submission
    return true;
}

// Feedback Form Validation
function validateFeedbackForm() {
    const customerName = document.getElementById("customerName").value;
    const email = document.getElementById("email").value;
    const feedback = document.getElementById("feedback").value;

    // Validate Name
    if (customerName.trim() === "") {
        alert("Name cannot be empty.");
        return false;
    }

    // Validate Email with Regex
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert("Invalid email format.");
        return false;
    }

    // Validate Feedback Length
    if (feedback.trim().length < 10) {
        alert("Feedback must be at least 10 characters long.");
        return false;
    }

    // If all validations pass, allow the form submission
    return true;
}
